/**
 * 
 */
package exam;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * @author user
 *
 */
public class S3 {
	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);
		Random random = new Random();
		
		int n = a.nextInt();
		
		int[] num = new int[n];
		
		for (int i = 0; i < n; i++) {
		
			num[i] = random.nextInt() + 1;
			System.out.print(num[i] + " ");
		}
		System.out.println();
		Arrays.sort(num);
		for (int c : num) {
			System.out.print(c + " ");
		}
	}
}
